<b>Shop_Testing_with_jUnit</b>

The testing method coverage upto 85%
![Screenshot](https://user-images.githubusercontent.com/53114804/203353350-2b7b5d6b-77c8-45e1-b5e1-558e473a370e.png)


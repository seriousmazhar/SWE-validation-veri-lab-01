package shopWithoutPayment;

public class Payment {
    public int TotalPrice;


    public Payment() {
        TotalPrice = 0;
    }


}
